</main>
	<footer>
		<ul class="ul-footer-information">
			<li>Rosales 8245</li>
			<li>Mar del Plata</li>
			<li>Argentina</li>
			<li>Tel: 54 223 4833687</li>
		</ul>
		<ul class="social-media-footer">
			<li><a href="https://instagram.com/zubillaga_puertas?igshid=YmMyMTA2M2Y=" target="_blank"><img src="img/desktop/ig_desktop.png" alt="Instagram logo link"></a></figcaption>
			</li>
			<li><a href="https://www.youtube.com/watch?v=KHe4EAMsJ-s" target="_blank"><img src="img/desktop/youtube_desktop.png" alt="Youtube logo link"></a></figcaption>
			</li>
		</ul>
	</footer>

</body>

</html>